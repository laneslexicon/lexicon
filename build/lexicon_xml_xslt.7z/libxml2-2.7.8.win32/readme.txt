  libxml2 2.7.8
  --------------

  This is libxml2, version 2.7.8, binary package for the native Win32/IA32
platform.

  The files in this package do not require any special installation
steps. Extract the contents of the archive whereever you wish and
make sure that your tools which use libxml2 can find it.

  For example, if you want to run the supplied utilities from the command
line, you can, if you wish, add the 'bin' subdirectory to the PATH
environment variable.
  If you want to make programmes in C which use libxml2, you'll
likely know how to use the contents of this package. If you don't, please
refer to your compiler's documentation.

  If there is something you cannot keep for yourself, such as a problem,
a cheer of joy, a comment or a suggestion, feel free to contact me using
the address below.

                              Igor Zlatkovic (igor@zlatkovic.com)
